#include "trans.h"

#define SC_INCLUDE_DYNAMIC_PROCESSES
#include <systemc>
#include <tlm.h>

using namespace sc_core;
using namespace tlm;

// <-- enter your implementation here

