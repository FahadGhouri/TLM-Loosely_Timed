#ifndef _TRANS_H_
#define _TRANS_H_

#define SC_INCLUDE_DYNAMIC_PROCESSES
#include <systemc>
#include <tlm.h>
#include <tlm_utils/simple_initiator_socket.h>
#include <tlm_utils/simple_target_socket.h>

SC_MODULE(trans_unit) {

  // <-- enter your implementation here
  SC_CTOR(trans_unit) {}
  // --> enter your implementation here

}; // END SC_MODULE "trans_unit"

#endif // _TRANS_H_

