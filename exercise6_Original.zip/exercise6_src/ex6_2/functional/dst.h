#ifndef _DST_H_
#define _DST_H_

class dst_unit {

  public:
  void send(int value);

}; // END CLASS "dst_unit"

#endif // _DST_H_

