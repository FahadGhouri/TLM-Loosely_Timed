#include "src.h"

int main(int argc, char* argv[]) {

  // instantiate a source_unit
  src_unit    source;

  // start the calculation
  source.start();

  return 0;

} // END MAIN

