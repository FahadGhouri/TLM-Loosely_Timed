#ifndef _SRC_H_
#define _SRC_H_

#include "trans.h"

class src_unit {

  public:
  void start();

  private:
  trans_unit  transform;

}; // END CLASS "src_unit"

#endif

