
#include "dst.h"

#include <cstdio>

using namespace std;

void dst_unit::send(int value) {

  // print the value as ASCII
  printf("%c",value);

} // END METHOD "send"

